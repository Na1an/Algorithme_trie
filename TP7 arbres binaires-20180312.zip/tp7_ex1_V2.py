#!/usr/bin/env python3

from tp7 import *
from tp7_ex1_test import *

def estVide(arbre) :
  return None

def etiquette(arbre, i) :
    return None

def filsGauche(arbre, i) :
  return None


def filsDroit(arbre, i) :
  return None

  
  
def pere(arbre, i) :
  return None

  

def estRacine(arbre, i) :
  return None


  
def estFilsGauche(arbre, i) :
  return None

  


def estFilsDroit(arbre, i) :
  return None



def estFeuille(arbre, i) :
  return None


    
if __name__ == '__main__':
  testAll()
